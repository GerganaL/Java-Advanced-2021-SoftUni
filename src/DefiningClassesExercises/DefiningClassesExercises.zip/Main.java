package DefiningClassesExercises;

import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;
import java.util.function.Predicate;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        Map<String,Person> people = new TreeMap<>();
        int n = Integer.parseInt(scan.nextLine());

        for (int i = 0; i < n; i++) {
            String[] info = scan.nextLine().split("\\s+");
            String name = info[0];
            int age = Integer.parseInt(info[1]);
            Person person = new Person(name,age);
            people.putIfAbsent(person.getName(), person);
        }

        people.entrySet().stream().filter(a -> a.getValue().getAge() > 30)
                .forEach(entry -> {
                    System.out.println(entry.getKey() + " - " + entry.getValue().getAge());
                });
    }
}
