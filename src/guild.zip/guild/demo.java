package guild;

import java.util.Scanner;

public class demo {
    static int playerRow;
    static int playerCol;
    static   int [] previous = new int[2];

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int size = Integer.parseInt(scan.nextLine());
        int countOfCommands = Integer.parseInt(scan.nextLine());

        char[][] matrix = new char[size][];

        readMatrix(scan, size, matrix);

        boolean won = false;


        while (countOfCommands-- > 0 && !won) {
            String command = scan.nextLine();
            switch (command) {
                case "up":
                    previous[0] = playerRow;
                    previous[1] = playerCol;
                    matrix[playerRow][playerCol] = '-';
                    playerRow--;
                    if (isOut(playerRow, playerCol, matrix)) {
                        playerRow = matrix.length - 1;

                    }
                    //move(playerRow,playerCol,matrix);
                    if (matrix[playerRow][playerCol] == 'B') {
                        playerRow--;
                        if (isOut(playerRow, playerCol, matrix)) {
                            playerRow = matrix.length - 1;
                        }
                    }
                    if (matrix[playerRow][playerCol] == 'T') {
                        matrix[previous[0]][previous[1]] = 'f';

                    } else if (matrix[playerRow][playerCol] == 'F') {
                        matrix[playerRow][playerCol] = 'f';
                        System.out.println("Player won!");
                        won = true;
                        break;
                    } else {
                        matrix[playerRow][playerCol] = 'f';

                    }
                    break;
                case "down":
                    previous[0] = playerRow;
                    previous[1] = playerCol;
                    matrix[playerRow][playerCol] = '-';
                    playerRow++;
                    if (isOut(playerRow, playerCol, matrix)) {
                        playerRow = 0;

                    }
                    //move(playerRow,playerCol,matrix);
                    if (matrix[playerRow][playerCol] == 'B') {
                        playerRow++;
                        if (isOut(playerRow, playerCol, matrix)) {
                            playerRow = 0;
                        }
                    }
                    if (matrix[playerRow][playerCol] == 'T') {
                        matrix[previous[0]][previous[1]] = 'f';

                    } else if (matrix[playerRow][playerCol] == 'F') {
                        matrix[playerRow][playerCol] = 'f';
                        System.out.println("Player won!");
                        won = true;
                        break;
                    } else {
                        matrix[playerRow][playerCol] = 'f';

                    }

                    break;
                case "left":
                    previous[0] = playerRow;
                    previous[1] = playerCol;
                    matrix[playerRow][playerCol] = '-';
                    playerCol--;
                    if (isOut(playerRow, playerCol, matrix)) {
                        playerCol = matrix[playerRow].length - 1;
                    }
                    if (matrix[playerRow][playerCol] == 'B') {
                        playerCol--;
                        if (isOut(playerRow, playerCol, matrix)) {
                            playerCol = matrix[playerRow].length - 1;
                        }
                    }
                    if (matrix[playerRow][playerCol] == 'T') {
                        matrix[previous[0]][previous[1]] = 'f';

                    } else if (matrix[playerRow][playerCol] == 'F') {
                        matrix[playerRow][playerCol] = 'f';
                        System.out.println("Player won!");
                        won = true;
                        break;
                    } else {
                        matrix[playerRow][playerCol] = 'f';

                    }

                    break;
                case "right":
                    previous[0] = playerRow;
                    previous[1] = playerCol;
                    matrix[playerRow][playerCol] = '-';
                    playerCol++;
                    if (isOut(playerRow, playerCol, matrix)) {
                        playerCol = 0;
                    }
                    if (matrix[playerRow][playerCol] == 'B') {
                        playerCol++;
                        if (isOut(playerRow, playerCol, matrix)) {
                            playerCol = 0;
                        }
                    }
                    if (matrix[playerRow][playerCol] == 'T') {
                        matrix[previous[0]][previous[1]] = 'f';

                    } else if (matrix[playerRow][playerCol] == 'F') {
                        matrix[playerRow][playerCol] = 'f';
                        System.out.println("Player won!");
                        won = true;
                        break;
                    } else {
                        matrix[playerRow][playerCol] = 'f';

                    }
                    break;
            }
        }

        if (!won) {
            System.out.println("Player lost!");
        }

        printMatrix(matrix);

    }

    private static void printMatrix(char[][] matrix) {
        for (char[] chars : matrix) {
            for (char aChar : chars) {
                System.out.print(aChar);
            }
            System.out.println();
        }
    }

    public static boolean isOut(int row, int col, char[][] matrix) {
        return row < 0 || row > matrix.length || col < 0 || col > matrix[row].length;
    }

    public static void readMatrix(Scanner scan, int size, char[][] matrix) {
        for (int row = 0; row < size; row++) {
            String currentRow = scan.nextLine();
            matrix[row] = currentRow.toCharArray();
            if (currentRow.contains("f")) {
                playerRow = row;
                for (int i = 0; i < currentRow.length(); i++) {
                    if (currentRow.charAt(i) == 'f') {
                        playerCol = i;
                    }
                }
            }
        }
    }
}
